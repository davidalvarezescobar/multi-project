import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gimnasio',
  templateUrl: './gimnasio.component.html',
  styleUrls: ['./gimnasio.component.scss']
})
export class GimnasioComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
