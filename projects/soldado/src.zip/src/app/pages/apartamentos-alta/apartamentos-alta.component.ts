import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-apartamentos-alta',
  templateUrl: './apartamentos-alta.component.html',
  styleUrls: ['./apartamentos-alta.component.scss']
})
export class ApartamentosAltaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
