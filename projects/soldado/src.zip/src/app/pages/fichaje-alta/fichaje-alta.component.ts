import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fichaje-alta',
  templateUrl: './fichaje-alta.component.html',
  styleUrls: ['./fichaje-alta.component.scss']
})
export class FichajeAltaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
