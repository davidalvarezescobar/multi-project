import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-guarderia-alta',
  templateUrl: './guarderia-alta.component.html',
  styleUrls: ['./guarderia-alta.component.scss']
})
export class GuarderiaAltaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
