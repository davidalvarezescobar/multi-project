import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-comedor-alta',
  templateUrl: './comedor-alta.component.html',
  styleUrls: ['./comedor-alta.component.scss']
})
export class ComedorAltaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
