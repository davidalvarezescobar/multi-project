import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gimnasio-alta',
  templateUrl: './gimnasio-alta.component.html',
  styleUrls: ['./gimnasio-alta.component.scss']
})
export class GimnasioAltaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
