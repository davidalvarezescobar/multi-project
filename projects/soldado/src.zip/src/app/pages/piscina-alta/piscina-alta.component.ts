import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-piscina-alta',
  templateUrl: './piscina-alta.component.html',
  styleUrls: ['./piscina-alta.component.scss']
})
export class PiscinaAltaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
