import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fichaje',
  templateUrl: './fichaje.component.html',
  styleUrls: ['./fichaje.component.scss']
})
export class FichajeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
