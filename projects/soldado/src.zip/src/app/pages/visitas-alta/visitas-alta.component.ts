import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-visitas-alta',
  templateUrl: './visitas-alta.component.html',
  styleUrls: ['./visitas-alta.component.scss']
})
export class VisitasAltaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
