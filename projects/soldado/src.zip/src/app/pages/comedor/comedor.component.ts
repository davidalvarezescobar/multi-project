import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-comedor',
  templateUrl: './comedor.component.html',
  styleUrls: ['./comedor.component.scss']
})
export class ComedorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
