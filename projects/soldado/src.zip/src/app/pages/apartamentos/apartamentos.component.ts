import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-apartamentos',
  templateUrl: './apartamentos.component.html',
  styleUrls: ['./apartamentos.component.scss']
})
export class ApartamentosComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
