import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-guarderia',
  templateUrl: './guarderia.component.html',
  styleUrls: ['./guarderia.component.scss']
})
export class GuarderiaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
