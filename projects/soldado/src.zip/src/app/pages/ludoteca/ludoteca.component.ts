import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ludoteca',
  templateUrl: './ludoteca.component.html',
  styleUrls: ['./ludoteca.component.scss']
})
export class LudotecaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
