import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-piscina',
  templateUrl: './piscina.component.html',
  styleUrls: ['./piscina.component.scss']
})
export class PiscinaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
