import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-biblioteca-alta',
  templateUrl: './biblioteca-alta.component.html',
  styleUrls: ['./biblioteca-alta.component.scss']
})
export class BibliotecaAltaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
