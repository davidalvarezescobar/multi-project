import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aparcamientos',
  templateUrl: './aparcamientos.component.html',
  styleUrls: ['./aparcamientos.component.scss']
})
export class AparcamientosComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
