import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-salas-alta',
  templateUrl: './salas-alta.component.html',
  styleUrls: ['./salas-alta.component.scss']
})
export class SalasAltaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
