import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-turnos-alta',
  templateUrl: './turnos-alta.component.html',
  styleUrls: ['./turnos-alta.component.scss']
})
export class TurnosAltaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
