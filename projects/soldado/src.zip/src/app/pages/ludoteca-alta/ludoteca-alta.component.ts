import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ludoteca-alta',
  templateUrl: './ludoteca-alta.component.html',
  styleUrls: ['./ludoteca-alta.component.scss']
})
export class LudotecaAltaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
